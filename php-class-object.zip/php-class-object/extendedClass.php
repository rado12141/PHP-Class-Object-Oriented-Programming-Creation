<?php 
/**
 * A sample PHP class that extends the other Class
 */
class extendedClass extends MySampleClass {
    public function getPropertyMethods(){
        ob_start();
        ?>
            <dl>
                <dt class="fw-light">Object Return Value:</dt>
                <dd class="ps-4"><pre><?php print_r($this); ?></pre></dd>
            </dl>
            <dl>
                <dt class="fw-light">Public Predefined Variable Value:</dt>
                <dd class="ps-4"><pre><?php print_r($this->publicVar); ?></pre></dd>
            </dl>
            <dl>
                <dt class="fw-light">Protected Predefined Variable Value:</dt>
                <dd class="ps-4"><pre><?php print_r($this->protectedVar ?? "Can't Access this Class method."); ?></pre></dd>
            </dl>
            <dl>
                <dt class="fw-light">Private Predefined Variable Value:</dt>
                <dd class="ps-4"><pre><?php print_r($this->privateVar ?? "Can't Access this Class method."); ?></pre></dd>
            </dl>
            <dl>
                <dt class="fw-light">Public Class Method Return Value:</dt>
                <dd class="ps-4"><pre><?php print_r($this->samplePublicMethod()); ?></pre></dd>
            </dl>
            <dl>
                <dt class="fw-light">Protected Class Method Return Value:</dt>
                <dd class="ps-4"><pre><?php print_r((is_callable([$this, 'sampleProtectedMethod'])) ?$this->sampleProtectedMethod() : "Permission Denied! Can't Access 'sampleProtectedMethod()' method."); ?></pre></dd>
            </dl>
        <?php
            return ob_get_clean();
    }
}