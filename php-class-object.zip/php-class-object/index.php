<?php require_once('MySampleClass.php')  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP OOP - Classes and Objects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

    <script src="assets/js/script.js"></script>
    <style>
        
    </style>
</head>
<body>
    <main>
        <nav class="navbar navbar-expand-lg navbar-dark bg-gradient">
            <div class="container">
                <a class="navbar-brand" href="./">PHP OOP - Classes and Objects</a>
                
                <div>
                    <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
                </div>
            </div>
        </nav>
        <div id="main-wrapper">
            <div class="container-fluid px-5 my-3" >
                <script>
                    start_loader()
                </script>
                <div class="row">
                <div class="mx-auto col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card rounded-0 mb-3 shadow">
                        <div class="card-header rounded-0">
                            <div class="card-title"><b>Calling the Class Property or Methods Outside the Class</b></div>
                        </div>
                        <div class="card-body rounded-0">
                            <div class="container-fluid">
                                <!-- PHP Class Method Execution -->
                                <div>
                                    <dl>
                                        <dt class="fw-light">Object Return Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r($sampleClass); ?></pre></dd>
                                    </dl>
                                    <dl>
                                        <dt class="fw-light">Public Predefined Variable Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r($sampleClass->publicVar); ?></pre></dd>
                                    </dl>
                                    <dl>
                                        <dt class="fw-light">Protected Predefined Variable Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r($sampleClass->protectedVar ?? "Can't Access this Class method."); ?></pre></dd>
                                    </dl>
                                    <dl>
                                        <dt class="fw-light">Private Predefined Variable Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r($sampleClass->privateVar ?? "Can't Access this Class method."); ?></pre></dd>
                                    </dl>
                                    <dl>
                                        <dt class="fw-light">Public Class Method Return Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r($sampleClass->samplePublicMethod()); ?></pre></dd>
                                    </dl>
                                    <dl>
                                        <dt class="fw-light">Protected Class Method Return Value:</dt>
                                        <dd class="ps-4"><pre><?php print_r((is_callable([$sampleClass, 'sampleProtectedMethod'])) ?$sampleClass->sampleProtectedMethod() : "Permission Denied! Can't Access 'sampleProtectedMethod()' method."); ?></pre></dd>
                                    </dl>
                                </div>
                                <!-- End of PHP Try Catch Error Handling Snippet -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mx-auto col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card rounded-0 mb-3 shadow">
                        <div class="card-header rounded-0">
                            <div class="card-title"><b>Calling the Class Property or Methods Inside the Class</b></div>
                        </div>
                        <div class="card-body rounded-0">
                            <div class="container-fluid">
                                <!-- PHP Class Method Execution -->
                                <div>
                                    <?= $sampleClass->executeInsideClass() ?>
                                </div>
                                <!-- End of PHP Try Catch Error Handling Snippet -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mx-auto col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card rounded-0 mb-3 shadow">
                        <div class="card-header rounded-0">
                            <div class="card-title"><b>Calling the Class Property or Methods Inside the Extended Class</b></div>
                        </div>
                        <div class="card-body rounded-0">
                            <div class="container-fluid">
                                <!-- PHP Class Method Execution -->
                                <div>
                                    <?= $extendedClass->getPropertyMethods() ?>
                                </div>
                                <!-- End of PHP Try Catch Error Handling Snippet -->
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <footer class="bg-gradient shadow-top py-4 col-auto">
            <div class="">
                <div class="text-center text-light">
                    All Rights Reserved &copy; <span id="dt-year"></span> | <span class="text-light text-opacity-75">PHP OOP - Classes and Objects</span>
                </div>
                <div class="text-center">
                    <a href="mailto:oretnom23@gmail.com" class="text-decoration-none text-white">oretnom23@gmail.com</a>
                </div>
            </div>
        </footer>
    </main>
    
</body>
</html>